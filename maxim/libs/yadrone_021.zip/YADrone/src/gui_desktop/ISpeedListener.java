package gui_desktop;

public interface ISpeedListener
{

	public void speedUpdated(int speed);
	
}
