
package com.shigeodayo.ardrone.navdata.javadrone;

@SuppressWarnings("serial")
public class NavDataFormatException extends Exception
{

    public NavDataFormatException(String why)
    {
        super(why);
    }

}
